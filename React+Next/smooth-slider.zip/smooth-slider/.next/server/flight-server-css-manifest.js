self.__RSC_CSS_MANIFEST={
  "cssImports": {
    "E:\\VcTask\\React+Next\\smooth-slider\\app\\page.js": [
      "E:\\VcTask\\React+Next\\smooth-slider\\components\\Slider\\Slider.css"
    ],
    "E:\\VcTask\\React+Next\\smooth-slider\\app\\layout.js": [
      "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\font\\google\\target.css?{\"path\":\"app\\\\layout.js\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}",
      "E:\\VcTask\\React+Next\\smooth-slider\\app\\globals.css"
    ]
  },
  "cssModules": {
    "E:\\VcTask\\React+Next\\smooth-slider\\app\\page": [
      "E:\\VcTask\\React+Next\\smooth-slider\\app\\globals.css",
      "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\font\\google\\target.css?{\"path\":\"app\\\\layout.js\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}",
      "E:\\VcTask\\React+Next\\smooth-slider\\components\\Slider\\Slider.css"
    ]
  }
}