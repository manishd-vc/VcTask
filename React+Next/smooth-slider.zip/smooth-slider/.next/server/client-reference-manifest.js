self.__RSC_MANIFEST={
  "ssrModuleMapping": {
    "(app-client)/./node_modules/next/dist/client/components/app-router.js": {
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "*",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "default",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "getServerActionDispatcher": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "getServerActionDispatcher",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "urlToUrlWithoutFlightMarker": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "urlToUrlWithoutFlightMarker",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/error-boundary.js": {
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "*",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "default",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "ErrorBoundaryHandler": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "ErrorBoundaryHandler",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "ErrorBoundary": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "ErrorBoundary",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js": {
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/redirect-boundary.js",
        "name": "*",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/redirect-boundary.js",
        "name": "",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/redirect-boundary.js",
        "name": "default",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "RedirectErrorBoundary": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/redirect-boundary.js",
        "name": "RedirectErrorBoundary",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "RedirectBoundary": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/redirect-boundary.js",
        "name": "RedirectBoundary",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js": {
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
        "name": "*",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
        "name": "",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
        "name": "default",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/layout-router.js": {
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/layout-router.js",
        "name": "*",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/layout-router.js",
        "name": "",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/layout-router.js",
        "name": "default",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js": {
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/render-from-template-context.js",
        "name": "*",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/render-from-template-context.js",
        "name": "",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/render-from-template-context.js",
        "name": "default",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js": {
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
        "name": "*",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
        "name": "",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
        "name": "default",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      }
    },
    "(app-client)/./components/Slider/Slider.js": {
      "*": {
        "id": "(sc_client)/./components/Slider/Slider.js",
        "name": "*",
        "chunks": [
          "app/page:static/chunks/app/page.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./components/Slider/Slider.js",
        "name": "",
        "chunks": [
          "app/page:static/chunks/app/page.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./components/Slider/Slider.js",
        "name": "default",
        "chunks": [
          "app/page:static/chunks/app/page.js"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/image.js": {
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/image.js",
        "name": "*",
        "chunks": [
          "app/page:static/chunks/app/page.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/image.js",
        "name": "",
        "chunks": [
          "app/page:static/chunks/app/page.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/image.js",
        "name": "default",
        "chunks": [
          "app/page:static/chunks/app/page.js"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/shared/lib/head.js": {
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/shared/lib/head.js",
        "name": "*",
        "chunks": [
          "app/page:static/chunks/app/page.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./node_modules/next/dist/shared/lib/head.js",
        "name": "",
        "chunks": [
          "app/page:static/chunks/app/page.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/shared/lib/head.js",
        "name": "default",
        "chunks": [
          "app/page:static/chunks/app/page.js"
        ],
        "async": false
      },
      "defaultHead": {
        "id": "(sc_client)/./node_modules/next/dist/shared/lib/head.js",
        "name": "defaultHead",
        "chunks": [
          "app/page:static/chunks/app/page.js"
        ],
        "async": false
      }
    }
  },
  "edgeSSRModuleMapping": {},
  "cssFiles": {
    "E:\\VcTask\\React+Next\\smooth-slider\\app\\page": [
      "static/css/app/page.css"
    ],
    "E:\\VcTask\\React+Next\\smooth-slider\\app\\layout": [
      "static/css/app/layout.css"
    ]
  },
  "clientModules": {
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\app-router.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\app-router.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\app-router.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "default",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "default",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\app-router.js#getServerActionDispatcher": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "getServerActionDispatcher",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#getServerActionDispatcher": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "getServerActionDispatcher",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\app-router.js#urlToUrlWithoutFlightMarker": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "urlToUrlWithoutFlightMarker",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#urlToUrlWithoutFlightMarker": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "urlToUrlWithoutFlightMarker",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\error-boundary.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\error-boundary.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\error-boundary.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "default",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "default",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\error-boundary.js#ErrorBoundaryHandler": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "ErrorBoundaryHandler",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#ErrorBoundaryHandler": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "ErrorBoundaryHandler",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\error-boundary.js#ErrorBoundary": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "ErrorBoundary",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#ErrorBoundary": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "ErrorBoundary",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\redirect-boundary.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\redirect-boundary.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\redirect-boundary.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\redirect-boundary.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\redirect-boundary.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "default",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\redirect-boundary.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "default",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\redirect-boundary.js#RedirectErrorBoundary": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "RedirectErrorBoundary",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\redirect-boundary.js#RedirectErrorBoundary": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "RedirectErrorBoundary",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\redirect-boundary.js#RedirectBoundary": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "RedirectBoundary",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\redirect-boundary.js#RedirectBoundary": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "RedirectBoundary",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\router-reducer\\fetch-server-response.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\router-reducer\\fetch-server-response.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\router-reducer\\fetch-server-response.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\router-reducer\\fetch-server-response.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\router-reducer\\fetch-server-response.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
      "name": "default",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\router-reducer\\fetch-server-response.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
      "name": "default",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\shared\\lib\\app-router-context.js": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\shared\\lib\\app-router-context.js": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\shared\\lib\\app-router-context.js#": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\shared\\lib\\app-router-context.js#": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\shared\\lib\\app-router-context.js#CacheStates": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "CacheStates",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\shared\\lib\\app-router-context.js#CacheStates": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "CacheStates",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\shared\\lib\\app-router-context.js#AppRouterContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "AppRouterContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\shared\\lib\\app-router-context.js#AppRouterContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "AppRouterContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\shared\\lib\\app-router-context.js#LayoutRouterContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "LayoutRouterContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\shared\\lib\\app-router-context.js#LayoutRouterContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "LayoutRouterContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\shared\\lib\\app-router-context.js#GlobalLayoutRouterContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "GlobalLayoutRouterContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\shared\\lib\\app-router-context.js#GlobalLayoutRouterContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "GlobalLayoutRouterContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\shared\\lib\\app-router-context.js#TemplateContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "TemplateContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\shared\\lib\\app-router-context.js#TemplateContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "TemplateContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\shared\\lib\\hooks-client-context.js": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/hooks-client-context.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\shared\\lib\\hooks-client-context.js": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/hooks-client-context.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\shared\\lib\\hooks-client-context.js#": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/hooks-client-context.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\shared\\lib\\hooks-client-context.js#": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/hooks-client-context.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\shared\\lib\\hooks-client-context.js#SearchParamsContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/hooks-client-context.js",
      "name": "SearchParamsContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\shared\\lib\\hooks-client-context.js#SearchParamsContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/hooks-client-context.js",
      "name": "SearchParamsContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\shared\\lib\\hooks-client-context.js#PathnameContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/hooks-client-context.js",
      "name": "PathnameContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\shared\\lib\\hooks-client-context.js#PathnameContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/hooks-client-context.js",
      "name": "PathnameContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\shared\\lib\\server-inserted-html.js": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/server-inserted-html.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\shared\\lib\\server-inserted-html.js": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/server-inserted-html.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\shared\\lib\\server-inserted-html.js#": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/server-inserted-html.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\shared\\lib\\server-inserted-html.js#": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/server-inserted-html.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\shared\\lib\\server-inserted-html.js#ServerInsertedHTMLContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/server-inserted-html.js",
      "name": "ServerInsertedHTMLContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\shared\\lib\\server-inserted-html.js#ServerInsertedHTMLContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/server-inserted-html.js",
      "name": "ServerInsertedHTMLContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\shared\\lib\\server-inserted-html.js#useServerInsertedHTML": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/server-inserted-html.js",
      "name": "useServerInsertedHTML",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\shared\\lib\\server-inserted-html.js#useServerInsertedHTML": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/server-inserted-html.js",
      "name": "useServerInsertedHTML",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\layout-router.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "*",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\layout-router.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "*",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\layout-router.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\layout-router.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\layout-router.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "default",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\layout-router.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "default",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\render-from-template-context.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "*",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\render-from-template-context.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "*",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\render-from-template-context.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\render-from-template-context.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\render-from-template-context.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "default",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\render-from-template-context.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "default",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\static-generation-searchparams-bailout-provider.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
      "name": "*",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\static-generation-searchparams-bailout-provider.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
      "name": "*",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\static-generation-searchparams-bailout-provider.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
      "name": "",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\static-generation-searchparams-bailout-provider.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
      "name": "",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\components\\static-generation-searchparams-bailout-provider.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
      "name": "default",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\components\\static-generation-searchparams-bailout-provider.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
      "name": "default",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\components\\Slider\\Slider.css#": {
      "id": "null",
      "name": "default",
      "chunks": [
        "static/css/app/page.css"
      ]
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\components\\Slider\\Slider.js": {
      "id": "(app-client)/./components/Slider/Slider.js",
      "name": "*",
      "chunks": [
        "app/page:static/chunks/app/page.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\components\\Slider\\Slider.js#": {
      "id": "(app-client)/./components/Slider/Slider.js",
      "name": "",
      "chunks": [
        "app/page:static/chunks/app/page.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\components\\Slider\\Slider.js#default": {
      "id": "(app-client)/./components/Slider/Slider.js",
      "name": "default",
      "chunks": [
        "app/page:static/chunks/app/page.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\image.js": {
      "id": "(app-client)/./node_modules/next/dist/client/image.js",
      "name": "*",
      "chunks": [
        "app/page:static/chunks/app/page.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\image.js": {
      "id": "(app-client)/./node_modules/next/dist/client/image.js",
      "name": "*",
      "chunks": [
        "app/page:static/chunks/app/page.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\image.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/image.js",
      "name": "",
      "chunks": [
        "app/page:static/chunks/app/page.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\image.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/image.js",
      "name": "",
      "chunks": [
        "app/page:static/chunks/app/page.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\client\\image.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/image.js",
      "name": "default",
      "chunks": [
        "app/page:static/chunks/app/page.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\client\\image.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/image.js",
      "name": "default",
      "chunks": [
        "app/page:static/chunks/app/page.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\shared\\lib\\head.js": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/head.js",
      "name": "*",
      "chunks": [
        "app/page:static/chunks/app/page.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\shared\\lib\\head.js": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/head.js",
      "name": "*",
      "chunks": [
        "app/page:static/chunks/app/page.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\shared\\lib\\head.js#": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/head.js",
      "name": "",
      "chunks": [
        "app/page:static/chunks/app/page.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\shared\\lib\\head.js#": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/head.js",
      "name": "",
      "chunks": [
        "app/page:static/chunks/app/page.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\shared\\lib\\head.js#default": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/head.js",
      "name": "default",
      "chunks": [
        "app/page:static/chunks/app/page.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\shared\\lib\\head.js#default": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/head.js",
      "name": "default",
      "chunks": [
        "app/page:static/chunks/app/page.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\shared\\lib\\head.js#defaultHead": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/head.js",
      "name": "defaultHead",
      "chunks": [
        "app/page:static/chunks/app/page.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\dist\\esm\\shared\\lib\\head.js#defaultHead": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/head.js",
      "name": "defaultHead",
      "chunks": [
        "app/page:static/chunks/app/page.js"
      ],
      "async": false
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\app\\globals.css#": {
      "id": "null",
      "name": "default",
      "chunks": [
        "static/css/app/layout.css"
      ]
    },
    "E:\\VcTask\\React+Next\\smooth-slider\\node_modules\\next\\font\\google\\target.css?{\"path\":\"app\\\\layout.js\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}#": {
      "id": "null",
      "name": "default",
      "chunks": [
        "static/css/app/layout.css"
      ]
    }
  }
}