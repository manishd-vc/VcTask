const sliderData = [
  {
    title: 'George',
    index: 1,
    description: 'React Ninja',
    image: '/sliderImage/slider1.png',
  },
  {
    title: 'Palak',
    index: 1,
    description: 'React Ninja',
    image: '/sliderImage/slider2.png',
  },
  {
    title: 'Pankaj',
    index: 1,
    description: 'React Ninja',
    image: '/sliderImage/slider3.png',
  },
  {
    title: 'Stavan',
    index: 1,
    description: 'React Ninja',
    image: '/sliderImage/slider4.png',
  },
  {
    title: 'Raj',
    index: 1,
    description: 'React Ninja',
    image: '/sliderImage/slider5.png',
  },
  {
    title: 'Salonee',
    index: 1,
    description: 'React Ninja',
    image: '/sliderImage/slider6.png',
  },
  {
    title: 'Vishal',
    index: 1,
    description: 'React Ninja',
    image: '/sliderImage/slider7.png',
  },
  {
    title: 'Manish',
    index: 1,
    description: 'React Ninja',
    image: '/sliderImage/slider8.png',
  },
  {
    title: 'Dhaval',
    index: 1,
    description: 'React Ninja',
    image: '/sliderImage/slider9.png',
  },
  {
    title: 'Shivangi',
    index: 1,
    description: 'React Ninja',
    image: '/sliderImage/slider10.png',
  },
  {
    title: 'Hirva',
    index: 1,
    description: 'React Ninja',
    image: '/sliderImage/slider11.png',
  },
  {
    title: 'Reemu',
    index: 1,
    description: 'React Ninja',
    image: '/sliderImage/slider12.png',
  },
  {
    title: 'Krunal',
    index: 1,
    description: 'React Ninja',
    image: '/sliderImage/slider13.png',
  },
  {
    title: 'Chandan',
    index: 1,
    description: 'React Ninja',
    image: '/sliderImage/slider14.png',
  },
];
export default sliderData;
