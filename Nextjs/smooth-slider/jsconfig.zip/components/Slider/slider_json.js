const sliderData = [
  {
    title: 'slider title 1',
    index: 1,
    description: 'slider description',
    image: '/sliderImage.jpg',
  },
  {
    title: 'slider title 2',
    index: 2,
    description: 'slider description',
    image: '/sliderImage.jpg',
  },
  {
    title: 'slider title 3',
    index: 3,
    description: 'slider description',
    image: '/sliderImage.jpg',
  },
  {
    title: 'slider title 4',
    index: 4,
    description: 'slider description',
    image: '/sliderImage.jpg',
  },
  {
    title: 'slider title 5',
    index: 5,
    description: 'slider description',
    image: '/sliderImage.jpg',
  },
  {
    title: 'slider title 6',
    index: 6,
    description: 'slider description',
    image: '/sliderImage.jpg',
  },
  {
    title: 'slider title 7',
    index: 7,
    description: 'slider description',
    image: '/sliderImage.jpg',
  },
  {
    title: 'slider title 8',
    index: 8,
    description: 'slider description',
    image: '/sliderImage.jpg',
  },
  {
    title: 'slider title 9',
    index: 9,
    description: 'slider description',
    image: '/sliderImage.jpg',
  },
  {
    title: 'slider title 10',
    index: 10,
    description: 'slider description',
    image: '/sliderImage.jpg',
  },
  {
    title: 'slider title 11',
    index: 11,
    description: 'slider description',
    image: '/sliderImage.jpg',
  },
  {
    title: 'slider title 12',
    index: 12,
    description: 'slider description',
    image: '/sliderImage.jpg',
  },
  {
    title: 'slider title 13',
    index: 13,
    description: 'slider description',
    image: '/sliderImage.jpg',
  },
  {
    title: 'slider title 14',
    index: 14,
    description: 'slider description',
    image: '/sliderImage.jpg',
  },
  {
    title: 'slider title 15',
    index: 15,
    description: 'slider description',
    image: '/sliderImage.jpg',
  },
  {
    title: 'slider title 16',
    index: 16,
    description: 'slider description',
    image: '/sliderImage.jpg',
  },
];
export default sliderData;
